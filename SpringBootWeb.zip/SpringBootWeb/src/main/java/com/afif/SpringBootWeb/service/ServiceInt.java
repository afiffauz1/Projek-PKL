package com.afif.SpringBootWeb.service;

import com.afif.SpringBootWeb.model.Pegawai;
import com.afif.SpringBootWeb.model.UsulKartu;

import java.util.List;

public interface ServiceInt {

    List<Pegawai> search(String q);
    List<Pegawai> cetakKartu(String k);
    List<UsulKartu> cari(String c);
}