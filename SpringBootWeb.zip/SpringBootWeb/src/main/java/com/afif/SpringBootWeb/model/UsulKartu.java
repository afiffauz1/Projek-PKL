package com.afif.SpringBootWeb.model;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

@Entity
public class UsulKartu implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;


    @JoinColumn (name = "kode_instansi", referencedColumnName = "kodeinstansi")
    @ManyToOne
    private NomorKartu kodeinstansi;

    @JoinColumn (name = "kode_karpeg", referencedColumnName = "kodekarpeg")
    @ManyToOne
    private NomorKartu kodekarpeg;

    @JoinColumn (name = "kode_karsu", referencedColumnName = "kodekarsu")
    @ManyToOne
    private NomorKartu kodekarsu;

    @JoinColumn (name = "kode_karis", referencedColumnName = "kodekaris")
    @ManyToOne
    private NomorKartu kodekaris;

    @JoinColumn (name = "nip", referencedColumnName = "nip")
    @ManyToOne(fetch = FetchType.EAGER)
    private Pegawai nip;

    private String nomorurutkarpeg;
    private String nomorurutkarsu;
    private String nomorurutkaris;

    public UsulKartu(){}

    public UsulKartu(NomorKartu kodeinstansi, NomorKartu kodekarpeg, NomorKartu kodekarsu, NomorKartu kodekaris, Pegawai nip, String nomorurutkarpeg, String nomorurutkarsu, String nomorurutkaris) {
        this.kodeinstansi = kodeinstansi;
        this.kodekarpeg = kodekarpeg;
        this.kodekarsu = kodekarsu;
        this.kodekaris = kodekaris;
        this.nip = nip;
        this.nomorurutkarpeg = nomorurutkarpeg;
        this.nomorurutkarsu = nomorurutkarsu;
        this.nomorurutkaris = nomorurutkaris;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public NomorKartu getKodeinstansi() {
        return kodeinstansi;
    }

    public void setKodeinstansi(NomorKartu kodeinstansi) {
        this.kodeinstansi = kodeinstansi;
    }

    public NomorKartu getKodekarpeg() {
        return kodekarpeg;
    }

    public void setKodekarpeg(NomorKartu kodekarpeg) {
        this.kodekarpeg = kodekarpeg;
    }

    public NomorKartu getKodekarsu() {
        return kodekarsu;
    }

    public void setKodekarsu(NomorKartu kodekarsu) {
        this.kodekarsu = kodekarsu;
    }

    public NomorKartu getKodekaris() {
        return kodekaris;
    }

    public void setKodekaris(NomorKartu kodekaris) {
        this.kodekaris = kodekaris;
    }

    public Pegawai getNip() {
        return nip;
    }

    public void setNip(Pegawai nip) {
        this.nip = nip;
    }

    public String getNomorurutkarpeg() {
        return nomorurutkarpeg;
    }

    public void setNomorurutkarpeg(String nomorurutkarpeg) {
        this.nomorurutkarpeg = nomorurutkarpeg;
    }

    public String getNomorurutkarsu() {
        return nomorurutkarsu;
    }

    public void setNomorurutkarsu(String nomorurutkarsu) {
        this.nomorurutkarsu = nomorurutkarsu;
    }

    public String getNomorurutkaris() {
        return nomorurutkaris;
    }

    public void setNomorurutkaris(String nomorurutkaris) {
        this.nomorurutkaris = nomorurutkaris;
    }

    @Override
    public String toString() {
        return "UsulKarpeg{" +
                "id=" + id +
                ", kodeinstansi=" + kodeinstansi +
                ", kodekarpeg=" + kodekarpeg +
                ", kodekarsu=" + kodekarsu +
                ", kodekaris=" + kodekaris +
                ", nip=" + nip +
                ", nomorurutkarpeg='" + nomorurutkarpeg + '\'' +
                ", nomorurutkarsu='" + nomorurutkarsu + '\'' +
                ", nomorurutkaris='" + nomorurutkaris + '\'' +
                '}';
    }
}
