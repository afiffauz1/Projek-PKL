package com.afif.SpringBootWeb.controller;


import com.afif.SpringBootWeb.service.ApkService;
import com.afif.SpringBootWeb.model.Pegawai;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
public class MainController {

    @Autowired
    private ApkService apkService;

    @GetMapping("/")
    public String homeapk() {
        return "/pegawai/home";
    }

    @GetMapping("/manage")
    public String manage() {
        return "/pegawai/manage";
    }

    @GetMapping("/manage/tampilform")
    public String tampilForm(Model model) {
        model.addAttribute("pegawai", new Pegawai());
        return "/pegawai/newpegawaiForm";
    }

    @GetMapping("/usulan")
    public String indexUsulan() {
        return "/pegawai/daftarusulan";
    }

    @GetMapping("/enterForm")
    public String cetak() {
        return "/pegawai/enterNipForm";
    }

    @GetMapping("/index")
    public String indexPegawai(HttpServletRequest request) {
        request.setAttribute("pegawai", apkService.indexPegawai());
        return "/pegawai/index";
    }

    @GetMapping("/indexkarpeg")
    public String indexkarpeg(HttpServletRequest request) {
        request.setAttribute("usulkarpeg", apkService.indexusulkarpeg());
        return "/usulan/tampilusulkarpeg";
    }

    @GetMapping("/indexkaris")
    public String indexkaris(HttpServletRequest request){
        request.setAttribute("usulkaris",apkService.indexusulkaris());
        return "usulan/tampilusulkaris";
    }

    @GetMapping("/uruskartu")
    public String uruskartu(){
        return "/usulan/uruskartu";
    }


    @GetMapping("/usulkategori")
    public String usulkategori(){
        return "/usulan/usulkategori";
    }



    @PostMapping("/manage/save")
    public String savepegawai(@ModelAttribute Pegawai pegawai, BindingResult bindingResult, HttpServletRequest request) {

        apkService.save(pegawai);
        request.setAttribute("pegawai", apkService.indexPegawai());
        request.setAttribute("mode", "MODE_PEGAWAIS");
        return "/pegawai/index";
    }

    @GetMapping("/entercariusul")
    public String formcariusul() {
        return "/usulan/entercariusul";
    }

    @PostMapping("/cariusulan")
    public String search(@RequestParam(name = "s") String s, Model model) {
        String pria = "1";
        String wanita = "2";
        char index = s.charAt(14);
        String compare = Character.toString(index);

        if (s != null) {
            if (compare.equals(pria)) {
                model.addAttribute("usulkartu", apkService.cari(s));
                return "/pegawai/kartuPria";
            }
            else if (compare.equals(wanita)){
                model.addAttribute("usulkartu", apkService.cari(s));
                return "/pegawai/kartuWanita";
            }
        }else if (s.equals(null)){
            model.addAttribute("nullvalue",true);
            return "/pegawai/entercariusul";
        }

        model.addAttribute("invalidCredentials",true);
        return "/pegawai/entercariusul";
    }

    @GetMapping("/cetakKarpegDepan/{nip}")
    public String cetakKarpegDepan(@PathVariable String nip, Model model){
        model.addAttribute("usulkartu", apkService.cari(nip));
        return "/cetak/karpegdepan";
    }

    @GetMapping("/cetakKarpegBelakang/{nip}")
    public String cetakKarpegBelakang(@PathVariable String nip, Model model){
        model.addAttribute("usulkartu", apkService.cari(nip));
        return "/cetak/karpegbelakang";
    }

    @GetMapping("/cetakKarisDepan/{nip}")
    public String cetakKarisDepan(@PathVariable String nip, Model model){
        model.addAttribute("usulkartu", apkService.cari(nip));
        return "/cetak/karisdepan";
    }

    @GetMapping("/cetakKarisBelakang/{nip}")
    public String cetakKarisBelakang(@PathVariable String nip, Model model){
        model.addAttribute("usulkartu", apkService.cari(nip));
        return "/cetak/karisbelakang";
    }

    @GetMapping("/cetakKarsuDepan/{nip}")
    public String cetakkarsudepan(@PathVariable String nip, Model model){
        model.addAttribute("usulkartu", apkService.cari(nip));
        return "/cetak/karsudepan";
    }

    @GetMapping("/cetakKarsuBelakang/{nip}")
    public String cetakkarsubelakang(@PathVariable String nip, Model model){
        model.addAttribute("usulkartu", apkService.cari(nip));
        return "/cetak/karsubelakang";
    }

}
