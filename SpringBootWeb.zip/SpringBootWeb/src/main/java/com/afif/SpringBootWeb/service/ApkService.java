package com.afif.SpringBootWeb.service;

import com.afif.SpringBootWeb.model.Pegawai;
import com.afif.SpringBootWeb.model.UsulKartu;
import com.afif.SpringBootWeb.repository.PegawaiRepository;
import com.afif.SpringBootWeb.repository.UsulKartuRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ApkService implements ServiceInt {

    private final PegawaiRepository pegawaiRepository;
    private final UsulKartuRepository usulKartuRepository;

    public ApkService(PegawaiRepository pegawaiRepository, UsulKartuRepository usulKartuRepository) {
        this.pegawaiRepository = pegawaiRepository;
        this.usulKartuRepository = usulKartuRepository;
    }


    public List<Pegawai> indexPegawai(){
        List<Pegawai> pegawais = new ArrayList<>();
        for(Pegawai pegawai : pegawaiRepository.findAll()){
            pegawais.add(pegawai);
        }
        return pegawais;
    }

    public void save(Pegawai pegawai){
        pegawaiRepository.save(pegawai);
    }



    @Override
    public List<Pegawai> search(String q) {
        return pegawaiRepository.findByNip(q);
    }

    @Override
    public List<Pegawai> cetakKartu(String k) {
        return pegawaiRepository.findByNip(k);
    }

    @Override
    public List<UsulKartu> cari(String c) {
        return usulKartuRepository.findByNip_Nip(c);
    }

    public List<UsulKartu> indexusulkarpeg(){
        List<UsulKartu> usulkarpegs = new ArrayList<>();
        for(UsulKartu usulkarpeg : usulKartuRepository.findAll()){
            usulkarpegs.add(usulkarpeg);
        }
        return usulkarpegs;
    }

    public List<UsulKartu> indexusulkaris(){
        List<UsulKartu> usulkarises = new ArrayList<>();
        for(UsulKartu usulkaris : usulKartuRepository.findAll()){
            usulkarises.add(usulkaris);
        }
        return usulkarises;
    }


}

