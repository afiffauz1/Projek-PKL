package com.afif.SpringBootWeb.repository;

import com.afif.SpringBootWeb.model.Pegawai;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PegawaiRepository extends JpaRepository <Pegawai, Integer> {

    List<Pegawai> findByNip(String nip);
}
