package com.afif.SpringBootWeb.model;

import javax.persistence.Entity;


public class Usulan {
}
